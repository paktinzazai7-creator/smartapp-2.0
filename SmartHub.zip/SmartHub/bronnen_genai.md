# Bronvermelding GenAI

Bij de verbeteropdracht heb ik Claude (Anthropic) gebruikt.

## Gesprek (share-link)

PLAK HIER DE SHARE-LINK VAN HET GESPREK

## Prompt

Ik heb de opdracht en rubric van de verbeteropdracht Smart App MVP gegeven en mijn GitHub-repo,
en gevraagd om te helpen mijn app te verbeteren volgens de rubric.

## Antwoord (samenvatting van wat de AI heeft voorgesteld)

1. Het weerstation toegevoegd aan het hoofdmenu, zodat het hele project via één keuzemenu werkt.
2. `vraag_getal()` in `weerstation.py`: blijft vragen tot de invoer een geldig getal is (eerst crashte het programma bij tekst).
3. `vraag_systeem()` en `vraag_waarde()` in `smartappcontroller.py`: bij foute invoer mag de gebruiker het meteen opnieuw proberen.
4. Vaste paden `C:\Users\pakti\...` vervangen door `Path(__file__).parent`, zodat de app op elke computer werkt.
5. `os.startfile` in een try/except gezet, omdat dit alleen op Windows bestaat.
6. De API-call haalt nu ook wind en luchtvochtigheid op en geeft met `weerrapport()` uit het weerstation een advies voor het huis.

## Wat ik zelf heb gedaan

- De oorspronkelijke code (weerstation, Smart App Controller, API-call) heb ik zelf geschreven.
- Ik heb de verbeteringen doorgelezen, getest en kan ze uitleggen.
