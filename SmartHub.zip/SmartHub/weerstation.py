def Fahrenheit(temp_celsius):
    return 32 + 1.8 * temp_celsius
#functie voor fahrenheit omrekenen


def gevoelstemperatuur(temp_celsius, windsnelheid, luchtvochtigheid):
    return temp_celsius - (luchtvochtigheid / 100 * windsnelheid)
#functie om gevoelstemperatuur te berekenen


def weerrapport(temp_celsius, windsnelheid, luchtvochtigheid):
    gevoel = gevoelstemperatuur(temp_celsius, windsnelheid, luchtvochtigheid)

    if gevoel < 0 and windsnelheid > 10:
        return "Het is heel koud en het stormt! Verwarming helemaal aan!"
    elif gevoel < 0 and windsnelheid <= 10:
        return "Het is behoorlijk koud! Verwarming aan op de benedenverdieping!"

    elif 0 <= gevoel < 10 and windsnelheid > 12:
        return "Het is best koud en het waait; verwarming aan en roosters dicht!"

    elif 0 <= gevoel < 10 and windsnelheid <= 12:
        return "Het is een beetje koud, elektrische kachel op de benedenverdieping aan!"

    elif 10 <= gevoel < 22:
        return "Heerlijk weer, niet te koud of te warm."

    else:
        return "Warm! Airco aan!"
#functie berekent eerst de gevoelstemperatuur en bewaart die in een variabele, daarna controleert hij met if en elif hoe warm het is


def vraag_getal(vraag, minimum, maximum):
    while True:
        invoer = input(vraag).strip()

        if invoer == "":
            return None

        try:
            getal = float(invoer.replace(",", "."))
        except ValueError:
            print("Dat is geen getal. Probeer het opnieuw.")
            continue

        if minimum <= getal <= maximum:
            return getal

        print(f"Kies een getal tussen {minimum} en {maximum}. Probeer het opnieuw.")
#functie blijft vragen (while-loop) tot de gebruiker een geldig getal invult
#leeg laten = stoppen, dan geeft de functie None terug


def weerstation():
    totaal_temperatuur = 0
    aantal_dagen = 0

    print("\nWEERSTATION (laat een vraag leeg om te stoppen)")

    for dag in range(1, 8):
        temp_celsius = vraag_getal(f"Wat is op dag {dag} de temperatuur [C]: ", -50, 50)
        if temp_celsius is None:
            break

        windsnelheid = vraag_getal(f"Wat is op dag {dag} de windsnelheid [m/s]: ", 0, 60)
        if windsnelheid is None:
            break

        luchtvochtigheid = vraag_getal(f"Wat is op dag {dag} de vochtigheid [%]: ", 0, 100)
        if luchtvochtigheid is None:
            break

        temp_fahrenheit = Fahrenheit(temp_celsius)
        rapport = weerrapport(temp_celsius, windsnelheid, luchtvochtigheid)

        totaal_temperatuur += temp_celsius
        aantal_dagen += 1
        gemiddelde = round(totaal_temperatuur / aantal_dagen, 1)

        print(f"Het is {temp_celsius}C ({round(temp_fahrenheit, 1)}F)")
        print(rapport)
        print(f"Gem. temp tot nu toe is {gemiddelde}C")
        print("====================================================")

    print("Doei! Terug naar het hoofdmenu.")
#de for-loop gaat 7 dagen langs, += houdt het totaal en het aantal dagen bij voor het gemiddelde


if __name__ == "__main__":
    weerstation()
