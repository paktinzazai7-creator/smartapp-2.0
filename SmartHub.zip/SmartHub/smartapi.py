import json
from urllib.request import urlopen
from urllib.error import URLError

from weerstation import Fahrenheit, gevoelstemperatuur, weerrapport

URL = (
    "https://api.open-meteo.com/v1/forecast?latitude=52.09&longitude=5.12"
    "&current=temperature_2m,relative_humidity_2m,wind_speed_10m"
    "&wind_speed_unit=ms"
)


def haal_weer_op():
    with urlopen(URL, timeout=10) as antwoord:
        gegevens = json.load(antwoord)

    huidig = gegevens["current"]
    return (
        huidig["temperature_2m"],
        huidig["wind_speed_10m"],
        huidig["relative_humidity_2m"],
    )
#functie doet de API-call naar Open-Meteo en geeft temperatuur, wind en vochtigheid terug


def weer_utrecht():
    try:
        temp_celsius, windsnelheid, luchtvochtigheid = haal_weer_op()

    except (URLError, TimeoutError, OSError):
        print("Geen internetverbinding of de weerdienst reageert niet. Probeer het later opnieuw.")
        return

    except (ValueError, KeyError):
        print("De weerdienst gaf onverwachte gegevens terug.")
        return

    gevoel = gevoelstemperatuur(temp_celsius, windsnelheid, luchtvochtigheid)

    print("\nLIVE WEER IN UTRECHT")
    print(f"Temperatuur:       {temp_celsius} C ({round(Fahrenheit(temp_celsius), 1)} F)")
    print(f"Windsnelheid:      {windsnelheid} m/s")
    print(f"Luchtvochtigheid:  {luchtvochtigheid} %")
    print(f"Gevoelstemperatuur: {round(gevoel, 1)} C")
    print("Advies voor je huis:", weerrapport(temp_celsius, windsnelheid, luchtvochtigheid))
#het echte weer van nu gaat door dezelfde functies als het weerstation, zo krijg je meteen een advies voor je huis


if __name__ == "__main__":
    weer_utrecht()
