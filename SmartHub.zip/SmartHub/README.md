# SmartHub – Smart App MVP

Gemaakt door Paktin Zazai (VS1E, 1935905).

SmartHub is een slim huis-platform in Python met een keuzemenu op de command line.

## Starten

```
python main.py
```

Je hebt alleen Python 3 nodig, er zijn geen extra pakketten.

## Wat zit erin

| Bestand | Wat het doet |
|---|---|
| `main.py` | Hoofdmenu van SmartHub |
| `weerstation.py` | Weerstation: 7 dagen weer invoeren, gevoelstemperatuur, Fahrenheit, gemiddelde en advies |
| `smartappcontroller.py` | Smart App Controller: leest `input.txt`, berekent CV, ventilatie en bewatering en schrijft `output.txt`; waarden kun je overschrijven |
| `smartapi.py` | API-call naar Open-Meteo: live weer in Utrecht met advies voor je huis |
| `input.txt` / `output.txt` | Invoer- en uitvoerbestand van de controller |

## Bronnen

- Open-Meteo API: https://open-meteo.com/
- Gebruik van GenAI: zie `bronnen_genai.md`
