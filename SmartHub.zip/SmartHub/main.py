from weerstation import weerstation
from smartappcontroller import smart_app_controller
from smartapi import weer_utrecht


def start_platform():
    while True:
        print("\n========== SMARTHUB ==========")
        print("1. Weerstation")
        print("2. Smart App Controller")
        print("3. Live weer in Utrecht (API)")
        print("4. Stoppen")

        try:
            keuze = int(input("Kies een optie: "))
        except ValueError:
            print("Vul een getal in, 1 tot en met 4.")
            continue

        if keuze == 1:
            weerstation()

        elif keuze == 2:
            smart_app_controller()

        elif keuze == 3:
            weer_utrecht()

        elif keuze == 4:
            print("Programma gestopt. Tot ziens!")
            break

        else:
            print("Ongeldige keuze, kies 1 tot en met 4.")


if __name__ == "__main__":
    try:
        start_platform()
    except (KeyboardInterrupt, EOFError):
        print("\nProgramma gestopt.")
