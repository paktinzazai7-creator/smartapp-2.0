from pathlib import Path
import os

#de bestanden staan in dezelfde map als dit programma, zo werkt het op elke computer
MAP = Path(__file__).parent
inputFile = MAP / "input.txt"
outputFile = MAP / "output.txt"


def lees_dagen(inputFile):
    voorbeeld = """date numPeople tempSetpoint tempOutside precip
05-10-2024 2 19 8 7
06-10-2024 2 19 8 7
07-10-2024 1 19 9 3
08-10-2024 1 19 11 0
09-10-2024 1 19 10 3
10-10-2024 3 21 6 0
11-10-2024 3 21 4 0
"""

    if not inputFile.exists() or len(inputFile.read_text(encoding="utf-8-sig").splitlines()) < 2:
        inputFile.write_text(voorbeeld, encoding="utf-8")
        print("Voorbeeldgegevens in input.txt gezet")

    with open(inputFile, "r", encoding="utf-8-sig") as bestand:
        regels = bestand.readlines()[1:]

    return [regel for regel in regels if regel.strip()]


def aantal_dagen(inputFile):
    return len(lees_dagen(inputFile))


def open_bestand(bestand):
    try:
        os.startfile(str(bestand))
    except (AttributeError, OSError):
        pass
#os.startfile bestaat alleen op Windows, op een andere computer slaan we het openen gewoon over


def auto_bereken(inputFile, outputFile):
    regels = lees_dagen(inputFile)
    uitvoer = []

    for regel in regels:
        try:
            datum, personen, setpoint, buiten, regen = regel.split()
            verschil = float(setpoint) - float(buiten)
            ventilatie = min(int(personen) + 1, 4)
            bewatering = float(regen) < 3
        except ValueError:
            print("Regel overgeslagen, die klopt niet:", regel.strip())
            continue

        if verschil >= 20:
            cv = 100
        elif verschil >= 10:
            cv = 50
        else:
            cv = 0

        uitvoer.append(f"{datum};{cv};{ventilatie};{bewatering}")

    with open(outputFile, "w", encoding="utf-8") as bestand:
        for regel in uitvoer:
            bestand.write(regel + "\n")

    print(len(uitvoer), "dagen opgeslagen")
    print("Bestand:", outputFile)
    print(outputFile.read_text(encoding="utf-8"))

    open_bestand(outputFile)


def vraag_systeem():
    while True:
        systeem = input("Systeem (1=CV, 2=Ventilatie, 3=Bewatering): ").strip()
        if systeem in ["1", "2", "3"]:
            return systeem
        print("Kies 1, 2 of 3.")


def vraag_waarde(systeem):
    while True:
        waarde = input("Nieuwe waarde: ").strip()

        try:
            getal = int(waarde)
        except ValueError:
            print("Vul een heel getal in.")
            continue

        if systeem == "1" and 0 <= getal <= 100:
            return str(getal)
        elif systeem == "2" and 0 <= getal <= 4:
            return str(getal)
        elif systeem == "3" and getal in [0, 1]:
            return str(bool(getal))

        if systeem == "1":
            print("CV moet tussen 0 en 100 zijn.")
        elif systeem == "2":
            print("Ventilatie moet tussen 0 en 4 zijn.")
        else:
            print("Bewatering is 0 (uit) of 1 (aan).")
#beide functies blijven vragen met een while-loop tot de invoer goed is


def overwrite_settings(outputFile):
    with open(outputFile, "r", encoding="utf-8") as bestand:
        regels = bestand.readlines()

    datums = [regel.split(";")[0] for regel in regels]

    while True:
        datum = input("Datum (bv. 05-10-2024, leeg = terug): ").strip()

        if datum == "":
            return -1

        if datum in datums:
            break

        print("Datum niet gevonden. Kies uit:", ", ".join(datums))

    systeem = vraag_systeem()
    nieuwe_waarde = vraag_waarde(systeem)

    i = datums.index(datum)
    gegevens = regels[i].strip().split(";")
    gegevens[int(systeem)] = nieuwe_waarde
    regels[i] = ";".join(gegevens) + "\n"

    with open(outputFile, "w", encoding="utf-8") as bestand:
        bestand.writelines(regels)

    return 0


def smart_app_controller():
    while True:
        print("\nSMART APP CONTROLLER")
        print("1. Aantal dagen")
        print("2. Automatisch berekenen")
        print("3. Waarde overschrijven")
        print("4. Terug naar hoofdmenu")

        keuze = input("Kies een optie: ").strip()

        try:
            if keuze == "1":
                print("Aantal dagen:", aantal_dagen(inputFile))

            elif keuze == "2":
                auto_bereken(inputFile, outputFile)

            elif keuze == "3":
                resultaat = overwrite_settings(outputFile)

                if resultaat == 0:
                    print("Waarde aangepast")
                    print(outputFile.read_text(encoding="utf-8"))
                    open_bestand(outputFile)
                else:
                    print("Niks aangepast")

            elif keuze == "4":
                break

            else:
                print("Ongeldige keuze, kies 1 tot en met 4.")

        except FileNotFoundError:
            print("Bestand niet gevonden. Kies eerst optie 2.")

        except (ValueError, OSError) as fout:
            print("Fout:", fout)


if __name__ == "__main__":
    smart_app_controller()
